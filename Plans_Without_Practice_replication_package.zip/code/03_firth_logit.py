"""
Firth penalized-likelihood logistic regression (Firth 1993), with
penalized likelihood-ratio (PLR) tests and profile penalized-likelihood
95% CIs (Heinze & Schemper 2002) — the recommended inference under
(quasi-)complete separation.

Implementation notes
- Penalized log-lik:  l*(b) = l(b) + 0.5 * log|I(b)|,  I = X'WX, W = diag(pi(1-pi))
- Modified score:     U*(b) = X' (y - pi + h * (0.5 - pi)),  h = diag of hat matrix
                      H = W^1/2 X (X'WX)^-1 X' W^1/2
- Newton-Raphson on U* with (X'WX)^-1 as step matrix and step-halving.
- Constrained fits (one coefficient fixed) keep the FULL-model information
  matrix in the penalty, as in R's logistf — so PLR tests/CIs are the
  standard Heinze-Schemper ones.
"""
import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import brentq
import warnings
warnings.filterwarnings("ignore")

np.set_printoptions(suppress=True, precision=4)


def _pi(X, b):
    z = np.clip(X @ b, -35, 35)
    return 1.0 / (1.0 + np.exp(-z))


def penalized_loglik(X, y, b):
    p = _pi(X, b)
    p = np.clip(p, 1e-12, 1 - 1e-12)
    ll = np.sum(y * np.log(p) + (1 - y) * np.log(1 - p))
    W = p * (1 - p)
    I = X.T @ (X * W[:, None])
    sign, logdet = np.linalg.slogdet(I)
    return ll + 0.5 * logdet


def fit_firth(X, y, fixed=None, max_iter=200, tol=1e-8, b0=None):
    """
    fixed: dict {col_index: value} of coefficients held fixed (for profile / PLR).
    Returns dict with beta, cov (Wald, free params on full-matrix inverse), ll_pen, converged, iters.
    """
    n, k = X.shape
    b = np.zeros(k) if b0 is None else b0.copy()
    fixed = fixed or {}
    for j, v in fixed.items():
        b[j] = v
    free = np.array([j for j in range(k) if j not in fixed])
    ll_old = penalized_loglik(X, y, b)
    converged = False
    for it in range(1, max_iter + 1):
        p = _pi(X, b)
        W = p * (1 - p)
        XW = X * W[:, None]
        I = X.T @ XW                       # full information matrix (penalty uses full I)
        I_inv = np.linalg.pinv(I)
        # hat-matrix diagonal: h_i = W_i * x_i' I^-1 x_i
        h = W * np.einsum("ij,jk,ik->i", X, I_inv, X)
        U_star = X.T @ (y - p + h * (0.5 - p))
        # Newton step on free coordinates only
        I_free = I[np.ix_(free, free)]
        step = np.zeros(k)
        # pinv rather than solve: constrained/profile fits can visit regions where W -> 0
        step[free] = np.linalg.pinv(I_free) @ U_star[free]
        # step-halving to guarantee ascent of the penalized likelihood
        lam = 1.0
        for _ in range(30):
            b_new = b + lam * step
            ll_new = penalized_loglik(X, y, b_new)
            if ll_new >= ll_old - 1e-12:
                break
            lam *= 0.5
        b = b_new
        if abs(ll_new - ll_old) < tol and np.max(np.abs(lam * step)) < 1e-6:
            converged = True
            ll_old = ll_new
            break
        ll_old = ll_new
    p = _pi(X, b)
    W = p * (1 - p)
    I = X.T @ (X * W[:, None])
    cov = np.linalg.pinv(I)
    return dict(beta=b, cov=cov, ll_pen=ll_old, converged=converged, iters=it, free=free)


def fit_firth_robust(X, y, fixed=None, b0_hint=None):
    """
    Multi-start Firth fit: Newton-Raphson from zeros and from a hint, then a
    quasi-Newton polish of the penalized log-likelihood over the free
    coordinates (independent of the NR/modified-score machinery). Returns the
    fit with the highest penalized log-likelihood.
    """
    from scipy.optimize import minimize
    fixed = fixed or {}
    k = X.shape[1]
    starts = [None]
    if b0_hint is not None:
        starts.append(b0_hint)
    fits = [fit_firth(X, y, fixed=fixed, b0=s) for s in starts]
    best = max(fits, key=lambda f: f["ll_pen"])
    free = best["free"]

    def negll(theta):
        b = best["beta"].copy()
        b[free] = theta
        return -penalized_loglik(X, y, b)

    res = minimize(negll, best["beta"][free], method="BFGS", options={"gtol": 1e-8, "maxiter": 500})
    if -res.fun > best["ll_pen"] + 1e-9:
        b = best["beta"].copy()
        b[free] = res.x
        best = fit_firth(X, y, fixed=fixed, b0=b)      # re-polish with NR from the BFGS optimum
        if -res.fun > best["ll_pen"]:
            best = dict(best, beta=b, ll_pen=-res.fun)
    return best


def plr_test(X, y, full_fit, j):
    """Penalized likelihood-ratio test of H0: beta_j = 0."""
    r = fit_firth_robust(X, y, fixed={j: 0.0}, b0_hint=full_fit["beta"])
    lr = 2.0 * (full_fit["ll_pen"] - r["ll_pen"])
    lr = max(lr, 0.0)
    return lr, stats.chi2.sf(lr, df=1)


def profile_ci(X, y, full_fit, j, alpha=0.05, span=25.0):
    """Profile penalized-likelihood CI for beta_j via root-finding."""
    bhat = full_fit["beta"][j]
    crit = stats.chi2.ppf(1 - alpha, df=1)
    llmax = full_fit["ll_pen"]

    def f(val):
        r = fit_firth_robust(X, y, fixed={j: val}, b0_hint=full_fit["beta"])
        return 2.0 * (llmax - r["ll_pen"]) - crit

    # search outward for a sign change on each side
    def find_root(direction):
        step = 0.5
        a = bhat
        while True:
            c = bhat + direction * step
            if f(c) > 0:
                lo, hi = (a, c) if direction > 0 else (c, a)
                return brentq(f, lo, hi, xtol=1e-4)
            a = c
            step *= 1.6
            if abs(c - bhat) > span:
                return np.nan  # unbounded within search span

    return find_root(-1), find_root(+1)


def run_model(name, df, outcome, predictors):
    d = df.dropna(subset=[outcome] + predictors).copy()
    X = np.column_stack([np.ones(len(d))] + [d[p].values.astype(float) for p in predictors])
    y = d[outcome].values.astype(float)
    labels = ["const"] + predictors
    fit = fit_firth_robust(X, y)
    # independent check: modified score should vanish at the optimum
    p = _pi(X, fit["beta"]); W = p * (1 - p); I = X.T @ (X * W[:, None])
    h = W * np.einsum("ij,jk,ik->i", X, np.linalg.pinv(I), X)
    score_norm = np.max(np.abs(X.T @ (y - p + h * (0.5 - p))))
    print(f"\n=== {name}: {outcome} ~ {' + '.join(predictors)}  (Firth) ===")
    print(f"n={len(d)}, outcome mean={y.mean():.3f}, converged={fit['converged']}, "
          f"penalized logL={fit['ll_pen']:.3f}, max|modified score|={score_norm:.2e}")
    rows = []
    for j, lab in enumerate(labels):
        se = np.sqrt(fit["cov"][j, j])
        wald_p = 2 * stats.norm.sf(abs(fit["beta"][j] / se)) if se > 0 else np.nan
        if lab == "const":
            lr, plr_p, lo, hi = np.nan, np.nan, np.nan, np.nan   # intercept inference not of interest
        else:
            lr, plr_p = plr_test(X, y, fit, j)
            lo, hi = profile_ci(X, y, fit, j)
        rows.append(dict(term=lab, beta=fit["beta"][j], se=se, wald_p=wald_p,
                         PLR_chi2=lr, PLR_p=plr_p, PL_CI_lo=lo, PL_CI_hi=hi,
                         OR=np.exp(fit["beta"][j]), OR_lo=np.exp(lo), OR_hi=np.exp(hi)))
    out = pd.DataFrame(rows)
    pd.set_option("display.width", 200)
    print(out.to_string(index=False, float_format=lambda v: f"{v:8.3f}"))
    # crosstabs for the binary predictors (to show the separation cells)
    for p in predictors:
        if set(np.unique(d[p].dropna())) <= {0, 1}:
            ct = pd.crosstab(d[p], d[outcome])
            print(f"  crosstab {p} x {outcome}:\n{ct.to_string()}")
    return out


if __name__ == "__main__":
    norm_m = pd.read_csv("../data/processed/rm_merged_normative.csv")
    org_m = pd.read_csv("../data/processed/rm_merged_organizational.csv")
    org_m["log_pob_comunal"] = np.log(org_m["pob_comunal"])
    if "log_pob_comunal" not in norm_m.columns:
        norm_m["log_pob_comunal"] = np.log(norm_m["pob_comunal"])

    preds = ["san_ramon_fault_exposure", "tiene_plareco", "log_pob_comunal"]
    results = {}
    results["plan_emergencia"] = run_model("NORMATIVE", norm_m, "plan_emergencia", preds)
    results["plan_rdd"] = run_model("NORMATIVE", norm_m, "plan_rdd", preds)
    results["unidad_grd"] = run_model("ORGANIZATIONAL", org_m, "unidad_grd", preds)
    results["director_grd"] = run_model("ORGANIZATIONAL", org_m, "director_grd", preds)

    with pd.ExcelWriter("../outputs/firth_results.xlsx") as xw:
        for k, v in results.items():
            v.to_excel(xw, sheet_name=k, index=False)
    print("\nSaved ../outputs/firth_results.xlsx")
