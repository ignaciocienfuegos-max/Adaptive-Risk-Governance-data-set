import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

# Palette (validated: dataviz skill, categorical slots 1 & 2)
BLUE = '#2a78d6'      # Normative
ORANGE = '#eb6834'    # Organizational
INK = '#0b0b0b'
MUTED = '#52514e'
GRID = '#e3e2dd'

plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.size': 11,
    'text.color': INK,
    'axes.edgecolor': MUTED,
    'axes.labelcolor': INK,
    'xtick.color': INK,
    'ytick.color': INK,
    'axes.grid': False,
})

norm_m = pd.read_csv('../data/processed/rm_merged_normative.csv')
org_m = pd.read_csv('../data/processed/rm_merged_organizational.csv')

# ---------- FIGURE 1: grouped bar chart, group means ----------
exposed_norm = norm_m[norm_m['san_ramon_fault_exposure']==1]['indice_planes'].mean()
rest_norm = norm_m[norm_m['san_ramon_fault_exposure']==0]['indice_planes'].mean()
exposed_org = org_m[(org_m['san_ramon_fault_exposure']==1) & org_m['indice_unidad'].notna()]['indice_unidad'].mean()
rest_org = org_m[(org_m['san_ramon_fault_exposure']==0) & org_m['indice_unidad'].notna()]['indice_unidad'].mean()

n_exp_norm = (norm_m['san_ramon_fault_exposure']==1).sum()
n_rest_norm = (norm_m['san_ramon_fault_exposure']==0).sum()
n_exp_org = ((org_m['san_ramon_fault_exposure']==1) & org_m['indice_unidad'].notna()).sum()
n_rest_org = ((org_m['san_ramon_fault_exposure']==0) & org_m['indice_unidad'].notna()).sum()

fig, ax = plt.subplots(figsize=(7.2, 5.0), dpi=200)

groups = ['Fault-exposed\ncommunes', 'Rest of the RM']
x = np.arange(len(groups))
width = 0.32

norm_vals = [exposed_norm, rest_norm]
org_vals = [exposed_org, rest_org]

bars1 = ax.bar(x - width/2 - 0.02, norm_vals, width, label='Normative index (0–2)', color=BLUE, zorder=3)
bars2 = ax.bar(x + width/2 + 0.02, org_vals, width, label='Organizational index (0–2)', color=ORANGE, zorder=3)

for b, v in zip(bars1, norm_vals):
    ax.text(b.get_x()+b.get_width()/2, v+0.04, f'{v:.2f}', ha='center', va='bottom', fontsize=10.5, color=INK)
for b, v in zip(bars2, org_vals):
    ax.text(b.get_x()+b.get_width()/2, v+0.04, f'{v:.2f}', ha='center', va='bottom', fontsize=10.5, color=INK)

ax.set_xticks(x)
ax.set_xticklabels([f'{groups[0]}\n(n={n_exp_norm})', f'{groups[1]}\n(n={n_rest_norm})'], fontsize=10.5)
ax.set_ylabel('Index value (0–2)', fontsize=11)
ax.set_ylim(0, 1.5)
ax.spines[['top','right']].set_visible(False)
ax.spines[['left','bottom']].set_color(MUTED)
ax.yaxis.grid(True, color=GRID, linewidth=0.8, zorder=0)
ax.set_axisbelow(True)
ax.legend(frameon=False, loc='upper left', fontsize=10.5, bbox_to_anchor=(0.0, 1.02))
ax.set_title('Normative capacity leads, organizational capacity lags,\namong the RM’s fault-exposed communes', fontsize=12.5, pad=14, loc='left')
fig.text(0.01, -0.02, 'Note: fault exposure = the six communes the ERD-RM 2024–2035 lists as exposed to the San Ramón fault\n(Vitacura, Las Condes, La Reina, Peñalolén, La Florida, Puente Alto). Organizational index n=5 (exposed): Puente Alto record missing.',
         fontsize=8.2, color=MUTED, ha='left')

fig.tight_layout()
fig.savefig('../outputs/figures/figure_decoupling_bars.png', bbox_inches='tight', facecolor='white', dpi=600)
print('Figure 1 saved.')
print('Values:', norm_vals, org_vals)

# ---------- FIGURE 2: scatter of all 52 communes, normative vs organizational ----------
merged = norm_m[['comuna','indice_planes','san_ramon_fault_exposure']].merge(
    org_m[['comuna','indice_unidad']], on='comuna', how='left'
)
merged = merged.dropna(subset=['indice_planes','indice_unidad'])

exposed = merged[merged['san_ramon_fault_exposure']==1]
rest = merged[merged['san_ramon_fault_exposure']==0]

fig2, ax2 = plt.subplots(figsize=(7.2, 6.2), dpi=200)

# jitter to reduce overplotting at integer grid points
rng = np.random.default_rng(42)
jit = 0.07
ax2.scatter(rest['indice_planes'] + rng.uniform(-jit, jit, len(rest)),
            rest['indice_unidad'] + rng.uniform(-jit, jit, len(rest)),
            s=46, color=MUTED, alpha=0.55, label=f'Rest of the RM (n={len(rest)})', zorder=3, edgecolors='none')
ax2.scatter(exposed['indice_planes'] + rng.uniform(-jit, jit, len(exposed)),
            exposed['indice_unidad'] + rng.uniform(-jit, jit, len(exposed)),
            s=100, color=ORANGE, alpha=0.95, label=f'Fault-exposed communes (n={len(exposed)})', zorder=4,
            edgecolors='white', linewidths=1.2)

# label the exposed communes (manual offsets to dodge the Las Condes / Peñalolén collision at (1,0))
name_fix = {'PENALOLEN': 'Peñalolén'}
label_offsets = {
    'LAS CONDES': (8, 11),
    'PENALOLEN': (8, -15),
    'LA FLORIDA': (8, 5),
    'LA REINA': (8, 5),
    'VITACURA': (8, 5),
}
for _, r in exposed.iterrows():
    label = name_fix.get(r['comuna'], r['comuna'].title())
    off = label_offsets.get(r['comuna'], (7, 5))
    ax2.annotate(label, (r['indice_planes'], r['indice_unidad']),
                 xytext=off, textcoords='offset points', fontsize=9.3, color=INK, zorder=5)

ax2.set_xlabel('Normative index (formal plans, 0–2)', fontsize=11)
ax2.set_ylabel('Organizational index (DRM unit + head, 0–2)', fontsize=11)
ax2.set_xlim(-0.3, 2.4)
ax2.set_ylim(-0.3, 2.4)
ax2.set_xticks([0,1,2])
ax2.set_yticks([0,1,2])
ax2.spines[['top','right']].set_visible(False)
ax2.spines[['left','bottom']].set_color(MUTED)
ax2.grid(True, color=GRID, linewidth=0.8, zorder=0)
ax2.set_axisbelow(True)
ax2.legend(frameon=False, loc='upper left', fontsize=10.5)
ax2.set_title('Fault-exposed communes cluster high on plans, low on operational capacity',
               fontsize=12.5, pad=14, loc='left')
fig2.text(0.01, -0.02, 'Note: points jittered slightly to reduce overlap at shared index values (true values are integers 0, 1, or 2).\nFault exposure follows the ERD-RM 2024–2035 San Ramón fault list. Puente Alto omitted (missing organizational-variable record).',
          fontsize=8.2, color=MUTED, ha='left')

fig2.tight_layout()
fig2.savefig('../outputs/figures/figure_scatter_crosswalk.png', bbox_inches='tight', facecolor='white', dpi=600)
print('Figure 2 saved.')
print(exposed[['comuna','indice_planes','indice_unidad']])
