"""
Code the ACHM/GORE Metropolitano 2024 technical-assistance program variable
(achm_gore_2024) and append it to the two merged analysis files.

This variable is NOT derived from any of the raw spreadsheets in data/raw/.
It was hand-coded from public ACHM (Asociación Chilena de Municipalidades)
press materials (April 2024) describing a GORE Metropolitano-funded ACHM
project that produced formal Disaster Risk Reduction (RDD) plans, Municipal
Emergency Plans, and threat-assessment annexes for 19 named RM communes.
See the manuscript's Research Design notes (§6, "The ACHM/GORE Metropolitano
2024 technical-assistance program") for the full discussion and sourcing.

achm_gore_2024 is used only as a supplementary/robustness condition (the
ASSIST condition in the fsQCA robustness check, code/05_fsqca.py) and plays
no role in the core Firth-logit or fsQCA models reported as the paper's
main findings.
"""
import re
import unicodedata
import pandas as pd

def norm(s):
    if pd.isna(s):
        return s
    s = str(s)
    s = unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode('ascii')
    s = s.upper().strip()
    s = re.sub(r'\s+', ' ', s)
    return s

# The 19 communes named in the April 2024 ACHM press materials as recipients
# of the GORE Metropolitano-funded RDD/emergency-plan technical assistance.
ACHM_GORE_2024_COMMUNES = {
    'CONCHALI', 'ESTACION CENTRAL', 'LA CISTERNA', 'LA FLORIDA', 'LA GRANJA',
    'LO PRADO', 'SAN MIGUEL', 'SAN RAMON', 'PEDRO AGUIRRE CERDA', 'LO ESPEJO',
    'LA PINTANA', 'CERRILLOS', 'QUILICURA', 'QUINTA NORMAL', 'LA REINA',
    'CERRO NAVIA', 'EL BOSQUE', 'MAIPU', 'RENCA',
}

OUT = '../data/processed/'

for fname in ['rm_merged_normative.csv', 'rm_merged_organizational.csv']:
    d = pd.read_csv(OUT + fname)
    d['achm_gore_2024'] = d['comuna'].apply(norm).isin(ACHM_GORE_2024_COMMUNES).astype(int)
    d.to_csv(OUT + fname, index=False)
    print(f"{fname}: achm_gore_2024 value counts")
    print(d['achm_gore_2024'].value_counts().to_string())

print("\nDone — both merged files now carry achm_gore_2024.")
