import re, unicodedata
import pandas as pd
import numpy as np
import pyreadr

pd.set_option('display.max_columns', None)
pd.set_option('display.width', 220)

def norm(s):
    if pd.isna(s):
        return s
    s = str(s)
    s = unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode('ascii')
    s = s.upper().strip()
    s = re.sub(r'\s+', ' ', s)
    return s

RECODE = {
    'PAIGUANO': 'PAIHUANO',
    'LA CALERA': 'CALERA',
    'EL OLIVAR': 'OLIVAR',
    'SAN VICENTE TT': 'SAN VICENTE',
    "O'HIGGINS": 'OHIGGINS',
    'O´HIGGINS': 'OHIGGINS',
    'CABO DE HORNOS Y ANTARTICA CHILENA': 'CABO DE HORNOS',
    'TIL TIL': 'TILTIL',
    'SAN PEDRO DE MELIPILLA': 'SAN PEDRO',
    'MARCHIGUE': 'MARCHIHUE',
}

def recode_comuna(s):
    s = norm(s)
    return RECODE.get(s, s)

RAW = '../data/raw/'
p22   = RAW + 'datos_municipales_2022.xlsx'
p23   = RAW + 'datos_municipales_2023.xlsx'
p_ach = RAW + 'datos_achm.xlsx'
p_el  = RAW + 'elec_munic_2021.xlsx'
p_pe  = RAW + 'planes_comunales_emergencia.xlsx'
p_pr  = RAW + 'planes_comunales_rdd.xlsx'
RDS   = RAW + 'sinim_data.rds'
OUT = '../data/processed/'

# 1) SINIM base -> RM communes
sinim = pyreadr.read_r(RDS)[None]
sinim['comuna_n'] = sinim['comuna'].apply(recode_comuna)
sinim['region_n'] = sinim['region'].apply(norm)
rm_communes = sorted(sinim.loc[sinim['region_n'] == 'METROPOLITANA', 'comuna_n'].unique().tolist())
print('N RM communes in SINIM:', len(rm_communes))

def sinim_year(year):
    d = sinim[(sinim['region_n'] == 'METROPOLITANA') & (sinim['year'] == year)].copy()
    d['log_pob_comunal'] = np.log1p(d['pob_comunal'])
    return d[['comuna_n','pob_comunal','log_pob_comunal','pobreza','profesionales']].rename(columns={'comuna_n':'comuna'})

sinim_2023 = sinim_year(2023)
sinim_2022 = sinim_year(2022)
print('sinim_2023 rows', sinim_2023.shape, 'sinim_2022 rows', sinim_2022.shape)

# 2) Plan formalization (normative dimension), 2024
def load_planes(path, colname):
    df = pd.read_excel(path, skiprows=1)
    df.columns = [norm(c).lower().replace(' ', '_') for c in df.columns]
    df = df.rename(columns={'ano':'ano', 'año':'ano'})
    # find the 'estado_de_revision...' col
    est_col = [c for c in df.columns if 'revision' in c][0]
    df['comuna'] = df['comuna'].apply(recode_comuna)
    df[colname] = (df[est_col].apply(norm) == 'PLAN FORMALIZADO').astype(int)
    df = df[df['ano'].astype(str) == '2024']
    return df[['comuna', colname]]

plan_em = load_planes(p_pe, 'plan_emergencia')
plan_rd = load_planes(p_pr, 'plan_rdd')
planes = plan_em.merge(plan_rd, on='comuna', how='outer')
planes['plan_emergencia'] = planes['plan_emergencia'].fillna(0)
planes['plan_rdd'] = planes['plan_rdd'].fillna(0)
planes['indice_planes'] = planes['plan_emergencia'] + planes['plan_rdd']
print('planes rows (national, 2024):', planes.shape)

consolidado_2023 = sinim_2023.merge(planes, on='comuna', how='left')
consolidado_2023['plan_emergencia'] = consolidado_2023['plan_emergencia'].fillna(0)
consolidado_2023['plan_rdd'] = consolidado_2023['plan_rdd'].fillna(0)
consolidado_2023['indice_planes'] = consolidado_2023['plan_emergencia'] + consolidado_2023['plan_rdd']

# 3) v_ind_2023 (datos_municipales_2023.xlsx)
v23 = pd.read_excel(p23)
v23.columns = [norm(c).lower() for c in v23.columns]
v23 = v23.rename(columns={'municipio':'comuna'})
v23['comuna'] = v23['comuna'].apply(recode_comuna)
for c in ['cosoc_constituido','ord_pc','tiene_pladeco','tiene_plareco']:
    v23[c] = v23[c].apply(lambda x: 1 if norm(x)=='SI' else (0 if norm(x)=='NO' else np.nan))
v23['dependencia_fcm'] = pd.to_numeric(v23['dependencia_fcm'].replace('NO RECEPCIONADO', np.nan), errors='coerce')
v23['ipp_per_capita'] = pd.to_numeric(v23['ipp_per_capita'], errors='coerce')
v23['pob_rural'] = pd.to_numeric(v23['pob_rural'], errors='coerce')
v23['trans_activa'] = pd.to_numeric(v23['trans_activa'], errors='coerce')

consolidado_2023 = consolidado_2023.merge(v23, on='comuna', how='left')
consolidado_2023['comuna_rural'] = (consolidado_2023['pob_rural'] > 60).astype(float)

# 4) participation 2021
el = pd.read_excel(p_el, skiprows=6)
el.columns = [norm(c).lower() for c in el.columns]
el['comuna'] = el['comuna'].apply(recode_comuna)
part = el.groupby('comuna', as_index=False).agg(inscritos=('inscritos','sum'), votos=('votos','sum'))
part['participacion'] = (part['votos']/part['inscritos']*100).round(2)
part = part[['comuna','participacion']]

consolidado_2023 = consolidado_2023.merge(part, on='comuna', how='left')

# ---- Restrict to RM ----
rm_2023 = consolidado_2023[consolidado_2023['comuna'].isin(rm_communes)].copy()
print('\\nRM 2023 consolidated shape:', rm_2023.shape)
print('Missing per RM commune (any NA in key cols):')
keycols = ['pob_comunal','pobreza','profesionales','plan_emergencia','plan_rdd','tiene_pladeco','tiene_plareco',
           'cosoc_constituido','ord_pc','trans_activa','participacion','comuna_rural']
print(rm_2023[['comuna'] + keycols].isna().sum())

rm_2023.to_csv(OUT + 'rm_2023_normative.csv', index=False)
print('\\nSaved rm_2023_normative.csv')
print(rm_2023[['comuna','plan_emergencia','plan_rdd','indice_planes','tiene_plareco','pob_comunal']].to_string())
