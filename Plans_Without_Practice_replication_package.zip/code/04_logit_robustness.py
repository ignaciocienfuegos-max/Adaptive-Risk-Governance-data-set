import pandas as pd
import numpy as np
import statsmodels.api as sm
import warnings
warnings.filterwarnings('ignore')

norm_m = pd.read_csv('../data/processed/rm_merged_normative.csv')
org_m = pd.read_csv('../data/processed/rm_merged_organizational.csv')
org_m['log_pob_comunal'] = np.log(org_m['pob_comunal'])

def prep(df, outcome_bin_col=None):
    d = df.copy()
    d = d.dropna(subset=['san_ramon_fault_exposure','tiene_plareco','log_pob_comunal'])
    return d

print("=== NORMATIVE: plan_emergencia ~ hazard + PRC + log(pop) ===")
d = prep(norm_m)
d = d.dropna(subset=['plan_emergencia'])
X = d[['san_ramon_fault_exposure','tiene_plareco','log_pob_comunal']]
X = sm.add_constant(X)
y = d['plan_emergencia']
print(f"n={len(d)}, outcome mean={y.mean():.3f}")
try:
    model = sm.Logit(y, X).fit(disp=0)
    print(model.summary2().tables[1])
except Exception as e:
    print("FAILED:", e)

print("\n=== NORMATIVE: plan_rdd ~ hazard + PRC + log(pop) ===")
d2 = prep(norm_m).dropna(subset=['plan_rdd'])
X2 = sm.add_constant(d2[['san_ramon_fault_exposure','tiene_plareco','log_pob_comunal']])
y2 = d2['plan_rdd']
print(f"n={len(d2)}, outcome mean={y2.mean():.3f}")
try:
    model2 = sm.Logit(y2, X2).fit(disp=0)
    print(model2.summary2().tables[1])
except Exception as e:
    print("FAILED:", e)

print("\n=== ORGANIZATIONAL: unidad_grd ~ hazard + PRC + log(pop) ===")
d3 = prep(org_m).dropna(subset=['unidad_grd'])
X3 = sm.add_constant(d3[['san_ramon_fault_exposure','tiene_plareco','log_pob_comunal']])
y3 = d3['unidad_grd']
print(f"n={len(d3)}, outcome mean={y3.mean():.3f}")
print("Cross-tab hazard x outcome:")
print(pd.crosstab(d3['san_ramon_fault_exposure'], d3['unidad_grd']))
try:
    model3 = sm.Logit(y3, X3).fit(disp=0, maxiter=200)
    print(model3.summary2().tables[1])
    print("Converged:", model3.mle_retvals.get('converged'))
except Exception as e:
    print("FAILED:", e)

print("\n=== ORGANIZATIONAL: director_grd ~ hazard + PRC + log(pop) ===")
d4 = prep(org_m).dropna(subset=['director_grd'])
X4 = sm.add_constant(d4[['san_ramon_fault_exposure','tiene_plareco','log_pob_comunal']])
y4 = d4['director_grd']
print(f"n={len(d4)}, outcome mean={y4.mean():.3f}")
try:
    model4 = sm.Logit(y4, X4).fit(disp=0, maxiter=200)
    print(model4.summary2().tables[1])
    print("Converged:", model4.mle_retvals.get('converged'))
except Exception as e:
    print("FAILED:", e)
