import pandas as pd
import numpy as np
import itertools
from sympy import symbols
from sympy.logic.boolalg import SOPform

pd.set_option('display.width', 160)
pd.set_option('display.max_columns', 30)

def calibrate(x, full_in, crossover, full_out):
    if pd.isna(x):
        return np.nan
    if x >= crossover:
        if full_in == crossover:
            return 1.0 if x > crossover else 0.5
        odds_log = 3.0 * (x - crossover) / (full_in - crossover)
        odds_log = min(odds_log, 6)
    else:
        if crossover == full_out:
            return 0.0 if x < crossover else 0.5
        odds_log = 3.0 * (x - crossover) / (crossover - full_out)
        odds_log = max(odds_log, -6)
    return 1.0 / (1.0 + np.exp(-odds_log))

def crispify(x):
    if pd.isna(x):
        return np.nan
    return 0.95 if x >= 0.5 else 0.05

def pct_thresholds(series):
    s = series.dropna()
    return np.percentile(s, 5), np.percentile(s, 50), np.percentile(s, 95)

norm_m = pd.read_csv('../data/processed/rm_merged_normative.csv')
org_m = pd.read_csv('../data/processed/rm_merged_organizational.csv')
org_m['log_pob_comunal'] = np.log(org_m['pob_comunal'])

def build_fs(df, outcome_raw, extra_conds=None):
    d = df.copy()
    lo, mid, hi = pct_thresholds(d['log_pob_comunal'])
    d['fs_POP'] = d['log_pob_comunal'].apply(lambda x: calibrate(x, hi, mid, lo))
    lo, mid, hi = pct_thresholds(d['trans_activa'])
    d['fs_CIVIC'] = d['trans_activa'].apply(lambda x: calibrate(x, hi, mid, lo))
    d['fs_PRC'] = d['tiene_plareco'].apply(crispify)
    d['fs_HAZARD'] = d['san_ramon_fault_exposure'].apply(crispify)
    if 'achm_gore_2024' in d.columns:
        d['fs_ASSIST'] = d['achm_gore_2024'].apply(crispify)
    d['fs_OUT'] = d[outcome_raw].apply(lambda x: calibrate(x, 2.0, 1.0, 0.0) if not pd.isna(x) else np.nan)
    base_cols = ['comuna','fs_PRC','fs_POP','fs_CIVIC','fs_HAZARD','fs_OUT', outcome_raw, 'san_ramon_fault_exposure']
    if 'fs_ASSIST' in d.columns:
        base_cols.append('fs_ASSIST')
    d = d[base_cols].dropna(subset=['fs_PRC','fs_POP','fs_CIVIC','fs_OUT'])
    return d

norm_fs = build_fs(norm_m, 'indice_planes')
org_fs  = build_fs(org_m, 'indice_unidad')

print("NORM n =", len(norm_fs), " ORG n =", len(org_fs))

CORE = ['fs_PRC','fs_POP','fs_CIVIC']

def truth_table(d, conds, freq_thresh=2, cons_thresh=0.80):
    rows = []
    for combo in itertools.product([0,1], repeat=len(conds)):
        mem = np.ones(len(d))
        for bit, c in zip(combo, conds):
            v = d[c].values if bit==1 else (1 - d[c].values)
            mem = np.minimum(mem, v)
        assigned = (mem > 0.5).sum()
        sum_mem = mem.sum()
        if sum_mem > 1e-9:
            num = np.minimum(mem, d['fs_OUT'].values).sum()
            consistency = num / sum_mem
            coverage = num / d['fs_OUT'].values.sum()
        else:
            consistency, coverage = np.nan, np.nan
        rows.append({'combo': combo, **{c:b for c,b in zip(conds, combo)},
                      'n_assigned': assigned, 'consistency': consistency, 'coverage': coverage})
    tt = pd.DataFrame(rows)
    tt['outcome'] = np.where((tt['n_assigned']>=freq_thresh) & (tt['consistency']>=cons_thresh), 1,
                      np.where(tt['n_assigned']>=freq_thresh, 0, np.nan))
    return tt

def solve(tt, conds, label):
    syms = symbols(' '.join([c.replace('fs_','') for c in conds]))
    minterms, dontcares, zeroterms = [], [], []
    for _, r in tt.iterrows():
        idx = int(''.join(str(b) for b in r['combo']), 2)
        if r['outcome']==1: minterms.append(idx)
        elif pd.isna(r['outcome']): dontcares.append(idx)
        else: zeroterms.append(idx)
    complex_sol = SOPform(syms, minterms, [])
    parsimonious_sol = SOPform(syms, minterms, dontcares)
    print(f"\n--- {label} ---")
    print(f"1-rows(outcome=1): {len(minterms)}  remainders: {len(dontcares)}  0-rows: {len(zeroterms)}")
    print("Complex/conservative solution:", complex_sol)
    print("Parsimonious solution        :", parsimonious_sol)
    return complex_sol, parsimonious_sol, minterms

def solution_consistency_coverage(d, conds, minterm_idxs):
    # overall solution membership per case = max over minterm-rows of (min over literals)
    n = len(d)
    sol_mem = np.zeros(n)
    for idx in minterm_idxs:
        bits = [int(b) for b in format(idx, f'0{len(conds)}b')]
        mem = np.ones(n)
        for bit, c in zip(bits, conds):
            v = d[c].values if bit==1 else (1-d[c].values)
            mem = np.minimum(mem, v)
        sol_mem = np.maximum(sol_mem, mem)
    num = np.minimum(sol_mem, d['fs_OUT'].values).sum()
    consistency = num / sol_mem.sum() if sol_mem.sum()>0 else np.nan
    coverage = num / d['fs_OUT'].values.sum()
    return consistency, coverage

for label, d, conds in [('NORMATIVE (PRC, POP, CIVIC)', norm_fs, CORE),
                          ('ORGANIZATIONAL (PRC, POP, CIVIC)', org_fs, CORE)]:
    print(f"\n############ {label}  n={len(d)} ############")
    tt = truth_table(d, conds)
    show = tt[tt['n_assigned']>0].sort_values(['n_assigned','consistency'], ascending=[False,False])
    print(show[conds+['n_assigned','consistency','coverage','outcome']].to_string(index=False))
    complex_sol, parsimonious_sol, minterms = solve(tt, conds, label)
    if minterms:
        cons, cov = solution_consistency_coverage(d, conds, minterms)
        print(f"Overall solution (1-rows only) consistency={cons:.3f} coverage={cov:.3f}")

# supplementary: normative model with ASSIST added (4 conditions) as robustness
print("\n\n############ SUPPLEMENTARY: NORMATIVE with ASSIST (PRC, POP, CIVIC, ASSIST) ############")
CORE4 = ['fs_PRC','fs_POP','fs_CIVIC','fs_ASSIST']
tt4 = truth_table(norm_fs, CORE4, freq_thresh=2, cons_thresh=0.80)
show4 = tt4[tt4['n_assigned']>0].sort_values(['n_assigned','consistency'], ascending=[False,False])
print(show4[CORE4+['n_assigned','consistency','coverage','outcome']].to_string(index=False))
solve(tt4, CORE4, 'NORMATIVE + ASSIST')

# ---- case-based crosswalk: where do the 6 hazard-exposed communes sit in the core configurational space? ----
def corner_label(row, conds):
    parts = []
    for c in conds:
        name = c.replace('fs_','')
        val = row[c]
        parts.append(name if val>0.5 else f"~{name}")
    return ' * '.join(parts)

print("\n\n=== Hazard-exposed communes: which corner of the core (PRC,POP,CIVIC) space do they occupy? ===")
for label, d in [('NORMATIVE', norm_fs), ('ORGANIZATIONAL', org_fs)]:
    print(f"\n-- {label} --")
    sub = d[d['san_ramon_fault_exposure']==1].copy()
    sub['corner'] = sub.apply(lambda r: corner_label(r, CORE), axis=1)
    print(sub[['comuna','fs_PRC','fs_POP','fs_CIVIC','fs_OUT','corner']].to_string(index=False))
