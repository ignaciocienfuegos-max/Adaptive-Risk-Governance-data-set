import re, unicodedata
import pandas as pd
import numpy as np
import pyreadr

pd.set_option('display.max_columns', None)
pd.set_option('display.width', 220)

def norm(s):
    if pd.isna(s):
        return s
    s = str(s)
    s = unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode('ascii')
    s = s.upper().strip()
    s = re.sub(r'\s+', ' ', s)
    return s

RECODE = {
    'PAIGUANO': 'PAIHUANO', 'LA CALERA': 'CALERA', 'EL OLIVAR': 'OLIVAR',
    'SAN VICENTE TT': 'SAN VICENTE', "O'HIGGINS": 'OHIGGINS', 'O´HIGGINS': 'OHIGGINS',
    'CABO DE HORNOS Y ANTARTICA CHILENA': 'CABO DE HORNOS', 'TIL TIL': 'TILTIL',
    'SAN PEDRO DE MELIPILLA': 'SAN PEDRO', 'MARCHIGUE': 'MARCHIHUE',
}
def recode_comuna(s):
    s = norm(s)
    return RECODE.get(s, s)

RAW = '../data/raw/'
p22   = RAW + 'datos_municipales_2022.xlsx'
p_ach = RAW + 'datos_achm.xlsx'
p_el  = RAW + 'elec_munic_2021.xlsx'
RDS   = RAW + 'sinim_data.rds'
OUT = '../data/processed/'

sinim = pyreadr.read_r(RDS)[None]
sinim['comuna_n'] = sinim['comuna'].apply(recode_comuna)
sinim['region_n'] = sinim['region'].apply(norm)
rm_communes = sorted(sinim.loc[sinim['region_n'] == 'METROPOLITANA', 'comuna_n'].unique().tolist())

def sinim_year(year):
    d = sinim[(sinim['region_n'] == 'METROPOLITANA') & (sinim['year'] == year)].copy()
    d['log_pob_comunal'] = np.log1p(d['pob_comunal'])
    return d[['comuna_n','pob_comunal','log_pob_comunal','pobreza','profesionales']].rename(columns={'comuna_n':'comuna'})

sinim_2022 = sinim_year(2022)

# ACHM survey (organizational dim, observed 2023) - use national 'Todas las Comunas' sheet for consistency with Script.R
ach = pd.read_excel(p_ach, sheet_name='Todas las Comunas')
ach.columns = [norm(c) for c in ach.columns]
col_unidad = [c for c in ach.columns if 'UNIDAD GESTION RIESGOS' in c and 'DIRECTOR' not in c][0]
col_dir    = [c for c in ach.columns if 'DIRECTOR' in c and 'JEFE' in c][0]
col_risk   = [c for c in ach.columns if 'RANKING' in c][0]
col_figem  = [c for c in ach.columns if 'TIPOLOGIA' in c][0]
ach2 = ach[['COMUNA', col_unidad, col_dir, col_risk, col_figem]].copy()
ach2.columns = ['comuna','unidad_grd_raw','director_grd_raw','risk_ranking','figem_group']
ach2['comuna'] = ach2['comuna'].apply(recode_comuna)
ach2 = ach2.dropna(subset=['comuna'])
ach2['unidad_grd'] = ach2['unidad_grd_raw'].apply(lambda x: 1 if norm(x)=='SI' else (0 if norm(x)=='NO' else np.nan))
ach2['director_grd'] = ach2['director_grd_raw'].apply(lambda x: 1 if norm(x)=='SI' else (0 if norm(x)=='NO' else np.nan))
ach2['indice_unidad'] = ach2['unidad_grd'] + ach2['director_grd']
ach2['risk_ranking'] = pd.to_numeric(ach2['risk_ranking'], errors='coerce')
ach2['figem_group'] = pd.to_numeric(ach2['figem_group'], errors='coerce')

consolidado_2022 = sinim_2022.merge(ach2[['comuna','unidad_grd','director_grd','indice_unidad','risk_ranking','figem_group']], on='comuna', how='left')

v22 = pd.read_excel(p22)
v22.columns = [norm(c).lower() for c in v22.columns]
v22 = v22.rename(columns={'municipio':'comuna'})
v22['comuna'] = v22['comuna'].apply(recode_comuna)
for c in ['cosoc_constituido','ord_pc','tiene_pladeco','tiene_plareco']:
    v22[c] = v22[c].apply(lambda x: 1 if norm(x)=='SI' else (0 if norm(x)=='NO' else np.nan))
v22['dependencia_fcm'] = pd.to_numeric(v22['dependencia_fcm'].replace('NO RECEPCIONADO', np.nan), errors='coerce')
v22['ipp_per_capita'] = pd.to_numeric(v22['ipp_per_capita'], errors='coerce')
v22['pob_rural'] = pd.to_numeric(v22['pob_rural'], errors='coerce')
v22['trans_activa'] = pd.to_numeric(v22['trans_activa'], errors='coerce')

consolidado_2022 = consolidado_2022.merge(v22, on='comuna', how='left')
consolidado_2022['comuna_rural'] = (consolidado_2022['pob_rural'] > 60).astype(float)

el = pd.read_excel(p_el, skiprows=6)
el.columns = [norm(c).lower() for c in el.columns]
el['comuna'] = el['comuna'].apply(recode_comuna)
part = el.groupby('comuna', as_index=False).agg(inscritos=('inscritos','sum'), votos=('votos','sum'))
part['participacion'] = (part['votos']/part['inscritos']*100).round(2)
consolidado_2022 = consolidado_2022.merge(part[['comuna','participacion']], on='comuna', how='left')

rm_2022 = consolidado_2022[consolidado_2022['comuna'].isin(rm_communes)].copy()
print('RM 2022 consolidated shape:', rm_2022.shape)
print(rm_2022[['comuna','unidad_grd','director_grd','indice_unidad','risk_ranking','figem_group','tiene_plareco']].isna().sum())
rm_2022.to_csv(OUT + 'rm_2022_organizational.csv', index=False)

# ---- Hazard-exposure dummies coded from ERD-RM 2035 narrative ----
san_ramon_fault = {'VITACURA','LAS CONDES','LA REINA','PENALOLEN','LA FLORIDA','PUENTE ALTO'}
piedemonte_flood = {'LO BARNECHEA','LAS CONDES','LA REINA','PENALOLEN','LA FLORIDA','PUENTE ALTO'}
poor_seismic_soil = {'LAMPA','COLINA','RENCA','CONCHALI','PUDAHUEL'}
volcanic_zone = {'SAN JOSE DE MAIPO'}
prc_gap_named = {'SAN JOSE DE MAIPO','TILTIL','MARIA PINTO','ALHUE','SAN PEDRO'}

rm_2023 = pd.read_csv(OUT + 'rm_2023_normative.csv')
ach_rm = ach2[ach2['comuna'].isin(rm_communes)][['comuna','risk_ranking','figem_group']]

merged_norm = rm_2023.merge(ach_rm, on='comuna', how='left')
merged_org  = rm_2022[['comuna','unidad_grd','director_grd','indice_unidad','risk_ranking','figem_group',
                       'tiene_pladeco','tiene_plareco','profesionales','ipp_per_capita','cosoc_constituido',
                       'ord_pc','participacion','trans_activa','pobreza','pob_comunal','comuna_rural']].copy()

for d in [merged_norm, merged_org]:
    d['san_ramon_fault_exposure'] = d['comuna'].isin(san_ramon_fault).astype(int)
    d['piedemonte_flood_risk'] = d['comuna'].isin(piedemonte_flood).astype(int)
    d['poor_seismic_soil'] = d['comuna'].isin(poor_seismic_soil).astype(int)
    d['volcanic_zone'] = d['comuna'].isin(volcanic_zone).astype(int)
    d['prc_gap_named'] = d['comuna'].isin(prc_gap_named).astype(int)

merged_norm.to_csv(OUT + 'rm_merged_normative.csv', index=False)
merged_org.to_csv(OUT + 'rm_merged_organizational.csv', index=False)

print('\\n--- Normative merged sample ---')
print(merged_norm[['comuna','indice_planes','tiene_plareco','risk_ranking','figem_group','san_ramon_fault_exposure','prc_gap_named']].to_string())
